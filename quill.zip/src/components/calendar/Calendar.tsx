import { spacing } from "@/src/constants/spacings";
import useCalendarCollapse from "@/src/hooks/useCalendarCollapse";
import useTheme from "@/src/hooks/useTheme";
import { Entry } from "@/src/types/entry";
import {
  addMonths,
  fromDateKey,
  getMonthWeeks,
  isSameDay,
  startOfMonth,
  toDateKey,
} from "@/src/utils/dates";
import { DatePicker } from "@quidone/react-native-wheel-picker";
import { useEffect, useMemo, useState } from "react";
import { View } from "react-native";
import { GestureDetector } from "react-native-gesture-handler";
import Animated from "react-native-reanimated";
import AppModal from "../ui/AppModal";
import CalendarHeader from "./CalendarHeader";
import MonthGrid from "./MonthGrid";
import NavButton from "./NavButton";
import WeekHeader from "./WeekHeader";

type CalendarProps = {
  entries: Entry[];
  selectedDate: Date | null;
  onDayPress: (date: Date) => void;
  onDayLongPress: (date: Date) => void;
};

export default function Calendar({
  entries,
  selectedDate,
  onDayPress,
  onDayLongPress,
}: CalendarProps) {
  const { colors } = useTheme();
  const [showPicker, setShowPicker] = useState(false);

  const today = useMemo(() => new Date(), []);
  const anchorDate = selectedDate ?? today;
  const anchorKey = toDateKey(anchorDate);

  const [currentMonth, setCurrentMonth] = useState(() =>
    startOfMonth(anchorDate),
  );

  const weeks = useMemo(() => getMonthWeeks(currentMonth, 0), [currentMonth]);

  const found = weeks.findIndex((w) => w.some((d) => isSameDay(d, anchorDate)));
  const selectedRow = found === -1 ? 0 : found;

  const {
    toggle,
    headerStyle,
    gridContainerStyle,
    gridStyle,
    panGesture,
    isExpanded,
    chevronRotation,
  } = useCalendarCollapse(selectedRow);

  useEffect(() => {
    setCurrentMonth(startOfMonth(fromDateKey(anchorKey)));
  }, [anchorKey, isExpanded]);

  const handlePrevMonth = () => setCurrentMonth((prev) => addMonths(prev, -1));
  const handleNextMonth = () => setCurrentMonth((prev) => addMonths(prev, 1));

  const navButton = (
    <Animated.View style={chevronRotation}>
      <NavButton icon={"chevron-up-outline"} onPress={toggle} />
    </Animated.View>
  );

  return (
    <View style={{ marginHorizontal: spacing.md }}>
      <Animated.View style={headerStyle}>
        <CalendarHeader
          month={currentMonth}
          onPrev={handlePrevMonth}
          onNext={handleNextMonth}
          onTitlePress={() => setShowPicker((prev) => !prev)}
        />
      </Animated.View>
      <WeekHeader weekStartOn={0} />
      <GestureDetector gesture={panGesture}>
        <View>
          <Animated.View style={[gridContainerStyle, { overflow: "hidden" }]}>
            <Animated.View style={gridStyle}>
              <MonthGrid
                entries={entries}
                month={currentMonth}
                weeks={weeks}
                selectedDate={selectedDate}
                onDayPress={onDayPress}
                onDayLongPress={onDayLongPress}
              />
            </Animated.View>
          </Animated.View>
          <View
            style={{
              justifyContent: "center",
              alignItems: "center",
            }}
          >
            {navButton}
          </View>
        </View>
      </GestureDetector>
      <AppModal
        title="Jump To"
        isOpen={showPicker}
        onClose={() => setShowPicker(false)}
      >
        <View style={{ alignItems: "center" }}>
          <DatePicker
            itemTextStyle={{ color: colors.text }}
            date={toDateKey(anchorDate)}
            onDateChanged={({ date }: { date: string }) =>
              onDayPress(new Date(date))
            }
          />
        </View>
      </AppModal>
    </View>
  );
}
